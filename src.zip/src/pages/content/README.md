# Content

The content page is a simple page meant for text content.
